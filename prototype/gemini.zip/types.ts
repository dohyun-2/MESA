
export enum SimulationStep {
  SETUP = 'SETUP',
  SIMULATING = 'SIMULATING',
  REPORT = 'REPORT'
}

export interface Metric {
  id: string;
  label: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  baseValue: number;
}

export interface AgentResponse {
  role: string;
  avatar: string;
  perspective: string;
  consensus: string;
  impactScore: number;
}

export interface SimulationResult {
  agents: AgentResponse[];
  summary: string;
  finalMetrics: {
    label: string;
    oldValue: string;
    newValue: string;
    trend: 'up' | 'down' | 'stable';
  }[];
}
