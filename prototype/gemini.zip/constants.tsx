
import { Metric } from './types';

export const INITIAL_METRICS: Metric[] = [
  {
    id: 'interest_rate',
    label: 'CENTRAL BANK INTEREST RATE',
    value: 4.25,
    unit: '%',
    min: 0,
    max: 15,
    baseValue: 4.25
  },
  {
    id: 'inflation',
    label: 'INFLATION TARGET',
    value: 2.1,
    unit: '%',
    min: -2,
    max: 10,
    baseValue: 2.1
  },
  {
    id: 'gdp_growth',
    label: 'GDP GROWTH PROJECTION',
    value: 1.8,
    unit: '%',
    min: -5,
    max: 10,
    baseValue: 1.8
  },
  {
    id: 'gov_spending',
    label: 'GOV. SPENDING EFFICIENCY',
    value: 72,
    unit: 'pts',
    min: 0,
    max: 100,
    baseValue: 72
  }
];

export const AGENT_ROLES = [
  { id: 'consumer', name: 'Household Consumer', avatar: 'https://picsum.photos/seed/consumer/100/100' },
  { id: 'business', name: 'Corporate Strategist', avatar: 'https://picsum.photos/seed/corp/100/100' },
  { id: 'government', name: 'Fiscal Authority', avatar: 'https://picsum.photos/seed/gov/100/100' },
  { id: 'centralbank', name: 'Monetary Guardian', avatar: 'https://picsum.photos/seed/bank/100/100' }
];
