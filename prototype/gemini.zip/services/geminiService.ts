
import { GoogleGenAI, Type } from "@google/genai";
import { Metric, SimulationResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function runSimulation(metrics: Metric[], context: string): Promise<SimulationResult> {
  const metricContext = metrics.map(m => `${m.label}: ${m.value}${m.unit} (Baseline: ${m.baseValue}${m.unit})`).join(', ');
  
  const prompt = `
    Conduct a multi-agent macroeconomic simulation.
    Variables: ${metricContext}
    Context/Scenario: ${context || "Standard market operations."}

    Steps:
    1. Each agent (Consumer, Business, Government, Central Bank) analyzes the changes from baseline.
    2. They debate the cascading effects.
    3. They reach a consensus on the 12-month outlook.

    Output the result in professional, high-level economic language.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          agents: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                role: { type: Type.STRING },
                perspective: { type: Type.STRING, description: "Individual agent initial thoughts" },
                consensus: { type: Type.STRING, description: "Agent's final position after debate" },
                impactScore: { type: Type.NUMBER, description: "-10 to 10 impact rating" }
              }
            }
          },
          summary: { type: Type.STRING, description: "Executive summary of the debate" },
          finalMetrics: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                oldValue: { type: Type.STRING },
                newValue: { type: Type.STRING },
                trend: { type: Type.STRING, description: "up, down, or stable" }
              }
            }
          }
        },
        required: ['agents', 'summary', 'finalMetrics']
      }
    }
  });

  try {
    const result = JSON.parse(response.text);
    return result as SimulationResult;
  } catch (e) {
    console.error("Failed to parse simulation result", e);
    throw new Error("Simulation engine failed to synthesize data.");
  }
}
